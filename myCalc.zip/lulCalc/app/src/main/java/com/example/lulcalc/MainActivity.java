package com.example.lulcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Stack;



public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView ans = (TextView) findViewById(R.id.ans);

        Button b0 = (Button) findViewById(R.id.button0);
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "0");
            }
        });

        Button b1 = (Button) findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "1");
            }
        });

        Button b2 = (Button) findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "2");
            }
        });

        Button b3 = (Button) findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "3");
            }
        });

        Button b4 = (Button) findViewById(R.id.button4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "4");
            }
        });

        Button b5 = (Button) findViewById(R.id.button5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "5");
            }
        });

        Button b6 = (Button) findViewById(R.id.button6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "6");
            }
        });

        Button b7 = (Button) findViewById(R.id.button7);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "7");
            }
        });
        Button b8 = (Button) findViewById(R.id.button8);
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "8");
            }
        });
        Button b9 = (Button) findViewById(R.id.button9);
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "9");
            }
        });
        Button bplus = (Button) findViewById(R.id.add);
        bplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "+");
            }
        });

        Button bsubtract = (Button) findViewById(R.id.subtract);
        bsubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "-");
            }
        });

        Button divide = (Button) findViewById(R.id.divide);
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "/");
            }
        });

        Button multiply = (Button) findViewById(R.id.muliply);
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText(omg + "*");
            }
        });

        Button c = (Button) findViewById(R.id.c);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();
                ans.setText("");
            }
        });

        Button equal = (Button) findViewById(R.id.equal);
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String omg = ans.getText().toString();









            }



        });



    }
}
